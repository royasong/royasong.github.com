VirtualKeyboard.Langs.KR.charProcessor;
