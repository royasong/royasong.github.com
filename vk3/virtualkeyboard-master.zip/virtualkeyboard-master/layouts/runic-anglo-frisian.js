﻿VirtualKeyboard.addLayout({code:'FY-ANCIENT',name:'Anglo-Frisian',normal:'ᛢᚫᛇᛠᛥᚸᚺᛤᛡᛟ᛭ᛩᚹᛖᚱᛏᚣᚢᛁᚩᛈᚪᛋᛞᚠᚷᚻᛄᛣᛚᛉᛪᚳᛝᛒᚾᛗ᛬᛫ᚦ',shift:{18:'ᛥ',30:'ᚸᚺ',33:'ᛤ',39:'ᛣ',42:'ᛝ'}});
