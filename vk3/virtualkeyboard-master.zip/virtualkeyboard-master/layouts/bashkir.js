﻿VirtualKeyboard.addLayout({code:'BA-RU',name:'Bashkir',normal:'ә!өҡғҫ:ҙһ?№-үңйцукенгшщзхъфывапролджэячсмитьбю.',shift:{1:'"',6:';',9:'()%',46:','}});
