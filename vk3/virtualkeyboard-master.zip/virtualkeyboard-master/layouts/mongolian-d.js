﻿VirtualKeyboard.addLayout({code:'MN',name:'Mongolian Cyrillic (QWERTY)',normal:'=!ыёү:;[]()шщ\\өеэртюуиопяъасдфгхжклйьзчцвбнм,./',shift:{0:'+№',5:'-*&₮_=',13:'|',44:'<>?'}});
