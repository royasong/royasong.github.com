﻿VirtualKeyboard.addLayout({code:'DIN',name:'Dinka',normal:'`1234567890-εŋqwertyuiopɔɣasdfghjkl;\'zxcvbnm,./',shift:{0:'~!@#$%^&*()_Ɛ',35:':"',44:'<>?'},caps:{12:'Ɛ'},shift_caps:{12:'ε'}});
