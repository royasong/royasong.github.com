﻿VirtualKeyboard.addLayout({code:'BG',name:'Bulgarian',normal:'`1234567890-.(,уеишщксдзц;ьяаожгтнвмчюйъэфхпрлб',shift:{0:'~!?+"%=:/_№ІV)ы',25:'§'}});
