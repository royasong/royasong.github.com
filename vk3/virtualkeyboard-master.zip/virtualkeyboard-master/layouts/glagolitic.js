﻿VirtualKeyboard.addLayout({code:'GLA-ANCIENT',name:'Glagolitic',normal:'ⱒⰷⱋⰼⱚⱛⱕⰺⱉⱙⱐⱏ※ⱑⱎⰵⱃⱅⱏⰹⱆⰹⱁⱂⱓⰶⰰⱄⰴⱇⰳⱍⰻⰽⰾ⁖ⰸⱈⱌⰲⰱⱀⰿⱔⱗⱘ',shift:{0:'Ⱊ',13:'ⱜ',36:'⁙',46:'Ⱙ'}});
