﻿VirtualKeyboard.addLayout({code:'BN-IN',name:'BN Inscript Improved',normal:'\u200d১২৩৪৫৬৭৮৯০-ৃ\\ৌৈাীূবহগদজড়োে্িুপরকতচটৎংমনবলস,.য়',shift:{0:'\u200c',9:'()ঃঋ|ঔঐআঈঊভঙঘধঝঢঞওএঅইউফঢ়খথছঠ?ঁণ',43:'শষ।য'}});
