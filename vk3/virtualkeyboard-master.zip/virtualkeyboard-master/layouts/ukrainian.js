﻿VirtualKeyboard.addLayout({code:'UK-UA',name:'Ukrainian',normal:'ё1234567890-=\\йцукенгшщзхїфівапролджєячсмитьбю.',shift:{1:'!"№;%:?*()_+/',46:','},alt:{20:'ґ'}});
