﻿VirtualKeyboard.addLayout({code:'AR-IQ',name:'Arabic',normal:'ذ1234567890-=\\ضصثقفغعهخحجدشسيبلاتنمكطئءؤرﻻىةورظ',shift:{0:'ّ!@#$%^&*)(_+|ًٌَُﻹإ‘÷×؛<>ٍِ[]ﻷأـ،/:"~ْ{}ﻵآ’,.؟'}});
