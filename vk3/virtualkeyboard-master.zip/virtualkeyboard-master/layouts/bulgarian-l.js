﻿VirtualKeyboard.addLayout({code:'BG',name:'Bulgarian (Latin)',normal:'`1234567890-=\\qwertyuiop[]asdfghjkl;\'zxcvbnm,./',shift:{0:'~!@#$%^&*()_+|',24:'{}',35:':"',44:'<>?'}});
