﻿VirtualKeyboard.addLayout({code:'TK',name:'Turkmen Cyrillic',normal:'ё\'!$&(җңөүә-ъэяшертыуиопющасдфгчйкльжзхцвбнм,.;',shift:{1:'"@%*)',11:'_',44:'<>:'}});
